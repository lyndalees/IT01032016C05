<?php 
$connect=mysqli_connect("localhost:3306", "root","","barang") or die("failed...");
?>
<!--'123456' tidak perlu tulis jika menggunakan local server yang tidak guna kata laluan-->

