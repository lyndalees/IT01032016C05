<!DOCTYPE html>
<html>
<head>
	<title>404 page not found</title>
</head>
<body>
	<img src="404.png">

</body>
</html>
