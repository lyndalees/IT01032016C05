<?php 
$connect=mysqli_connect("localhost:3306", "root","","barang") or die("failed...");
?>
