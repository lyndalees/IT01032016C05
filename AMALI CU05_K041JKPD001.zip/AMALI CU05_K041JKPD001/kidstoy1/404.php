<!DOCTYPE html>
<html>
<head>
	<center>
		<img src="maintenance.png">
	</center>
</head>
<body>
	<center>
		<p>THE PAGE IS CURRENTLY UNDER MAINTENANCE</p>
		<p>THE PAGE WILL BE AVAILABLE SOON</p>
		<p>PLEASE WAIT UNTIL THE PAGE IS READY</p>
	</center>
</body>
</html>
