<!DOCTYPE html>
<html>
<head>
	<title>404</title>
	<CENTER><h1>ERROR 404</h1></CENTER>
</head>
<body>
      <center><img src="404.jpeg" height="350px" width="350px"></center>
      <center>
      	<p>PAGE INI SEDANG DIBAIKPULIH</p>
      	<P>MINTA MAAF</P>
      	<P>HARAP ANDA BOLEH BERSABAR</P>
      </center>
</body>
</html>