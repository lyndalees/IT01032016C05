<!DOCTYPE html>
<html>
<head>
	<title>KIDS TOYS</title>
</head>
<body>
	<center>
		<h2>SENARAI BARANG MAINAN</h2>
		<!-- perkataan barang disalah eja tiada G !-->
<body style = "background-color:#D77EF0;">
   
		
		<table border="1" cellspacing="0" cellpadding="6">
		  <tr bgcolor="#eee">	

			<th>KOD PRODUK</th>
			<th>NAMA PRODUK</th>
        		<th>HARGA</th>
        		<th>KUANTITI</th>
        		<!-- perkataan kuantiti yang disalah eja !--> 

<td>HAPUS</td>
			
		  </tr>

		  <?php
		  	include 'config.php';
            //fail config1.php tidak wujud sepatutnya config.php//
		  	$papar=mysqli_query($connect,"SELECT * FROM jadualmainan");

		  	while ($row=mysqli_fetch_array($papar)) {
		  		$totalRecord=mysqli_num_rows($papar);
		  		
		  echo "
		  <tr>	
			<td>".$row['kod_produk']."</td>
			<td>".$row['nama_produk']."</td>
        		<td>".$row['harga']."</td>
        		<td>".$row['kuantiti']."</td>
<td><a href='delete.php?kod_produk=".$row['kod_produk']."' onclick='myHapus()'> Hapus </a></td>
		  </tr>";
		}
		  ?>
		</table>
<p><a href="error.php">Tambah Rekod</a></p>
		<!-- failtambah.php tidak wujud maka tukar kepada add.php !-->
	</center>

	
</body>
</html>


